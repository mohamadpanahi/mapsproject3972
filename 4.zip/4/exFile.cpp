#include "exFile.h"

exFile::exFile(const string& filename) :message("Error 404: \"" + filename + "\" not found :(") {}
exFile::~exFile() {}

const char* exFile::what() const
{
	return message.c_str();
}
